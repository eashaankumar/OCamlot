# Ocamlot

## Installation

`opam install js_of_ocaml js_of_ocaml-ocamlbuild js_of_ocaml-camlp4 js_of_ocaml-lwt`

`git clone https://github.coecis.cornell.edu/ek485/OCamlot`

run `make`

run index.html in browser

## Citations

- Lightning spell
http://spritefx.blogspot.fr/2013/04/sprite-lightning.html

- Freeze Spell
https://pixabay.com/en/berg-crystal-quartz-blue-crystal-160776/
